"""Common functionality."""
