"""Asynchronous WASI transport extensions."""
